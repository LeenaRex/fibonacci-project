var should = require('chai').should(),
expect = require('chai').expect,
supertest = require('supertest'),
api = supertest('http://localhost:3000');

// Test GET API
describe('Test API GET for Fibonnaci Number', function(){
	it('API GET should return a 200 response', function(done) {
		api.get('/')
		.set('Accept', 'application/json')
		.expect(200,done);
	});	

	it('API GET with parameter should return 200 response', function(done){
		api.get('/fibonacci?number=5')
		.set('Accept', 'application/json')
		.expect(200,done);		
	});

	it('API GET with input number 2 should equal [0,1]', function(done){
		api.get('/fibonacci?number=2')
		.set('Accept', 'application/json')
		.expect(200)
		.end(function(err, res) {
			expect(res.body).to.eql([ 0, 1 ]);
			done();
		});		
	});

	it('API GET with input number 5 should equal [0,1,1,2,3]', function(done){
		api.get('/fibonacci?number=5')
		.set('Accept', 'application/json')
		.expect(200)
		.end(function(err, res) {
			expect(res.body).to.eql([ 0, 1, 1, 2, 3 ]);
			done();
		});		
	});	
});

// Test POST API
describe('Test API POST for Fibonnaci Number', function(){
	it('API POST should return a 200 response', function(done) {
		api.post('/fibonacci')
		.set('Accept', 'application/json')
		.expect(200,done);

	});
});

// Negative Tests
describe('Negative Tests for Fibonnaci Number', function(){	
	it('API GET expected response message for negative number ', function(done){
		api.get('/fibonacci?number=-1')
		.set('Accept', 'application/json')
		.expect(200)
		.end(function(err, res) {
			expect(res.text).to.equal('Negative number is not a valid number to generate Fibonacci number');			
			done();
		});
	});	

	it('API GET expected response message for number greater than 1468', function(done){
		api.get('/fibonacci?number=1469')
		.set('Accept', 'application/json')
		.expect(200)
		.end(function(err, res) {
			expect(res.text).to.include('Due to array size limitation the number needs to be between ');			
			done();
		});
	});	

	it('API GET expected response message for number greater than 1468', function(done){
		api.get('/fibonacci?number=notNumber')
		.set('Accept', 'application/json')
		.expect(200)
		.end(function(err, res) {
			expect(res.text).to.include('Please enter a valid number');			
			done();
		});
	});		
});
	