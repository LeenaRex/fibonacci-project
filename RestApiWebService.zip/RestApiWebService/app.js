/**
 * @fileOverview Generate Fibonacci numbers
 *
 * @description Uses plain REST API for generating fiboacci numbers.<br>
 * The HTTP method GET is sufficient to fulfil the project requirement.<br>
 * The HTTP methods PUT and DELETE are not used.<br>
 * The HTTP method POST is used for GUI request and response
 * @author Leena Rex
 * @since 1.0.0
*/

/**
 * This project requires following modules
 * @requires modules - express, bodyParser, path
 */
const express = require('express');
const app = express();
var path = require('path');
var bodyParser = require('body-parser');

app.set('view engine', 'ejs');
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// create application/json parser
var jsonParser = bodyParser.json();

// create application/x-www-form-urlencoded parser
var urlencodedParser = bodyParser.urlencoded({ extended: false })

/**
 * Set port number to 3000 
 * Listen on port when server is started
 */
const port = 3000;
app.listen(port, () => console.log('Listening on port ' + port));

/**
 * REST API method GET takes a number as parameter in the request
 * and sends the computed Fibonacci numbers as response.
 * @api {get} /fibonacci
 * @apiName fibonacci
 * @apiParam {Number} Number
 * @apiSuccess {Number} fibonacci numbers
 * @apiFailuer {error} error message
 */
app.get('/fibonacci', function(req, res) {	
	// debug console.log('req.query.number is : ' + req.query.number);	

	// Call computeFib() to generate fibonacci numbers and send 
	// result to GET response send().		 
	res.send(computeFib(req.query.number));	
	res.end();
}); 

/**
 * Compute fibonacci numbers
 * The max limit is set to 1468 due to the limition in array data structure.
 * The number greater than 1468 only adds null to the array.
 * @param {number} num Input number to denote the number of fibonacci numbers to be generated.
 * @yields {Number} The fibonacci sequence numbers
 */
function computeFib(fibnum){
	// convert string number to integer
	var num = parseInt(fibnum);	
	const fibonacciNum = [];
	const min = 0;
	const max = 1468;	

	// validate the input number before generating Fibonacci numbers
	if( Number.isInteger(num) == false ){		
	 	return 'Please enter a valid number';	
	} else {	
		if(num < min ){
			return 'Negative number is not a valid number to generate Fibonacci number'
		} else if (num > max ) {		
			return ('Due to array size limitation the number needs to be between ' + min  + ' and ' + max);
		} else if(num == min){
			return 'Needs atleast 1 to generate the first fibonacci Numbers'
		} else if(num == 1){
			fibonacciNum[0] = 0;		
			return fibonacciNum;
		} else if (num > 1 && num <= max ) {
			fibonacciNum[0] = 0;
			fibonacciNum[1] = 1;
			for (var i = 2; i < num; i++) {
				fibonacciNum[i] = (fibonacciNum[i - 1] + fibonacciNum[i - 2]);
			}
			return fibonacciNum;
		}
	}		
}

/**
 * This GET method allows to enter input number through a webpage UI.
 * In the Web URL http://localhost:3000/ enter a number and click
 * submit button. The resul is displayed in the webpage.
 * @param {number} number
 * @yields {Number} The fibonacci sequence numbers
 */
app.get('/', function(req, res){ 	
 	res.render('index',{title:"Fibonacci",result: ""});
 	res.end();
});

/**
 * This POST method allows to get input from a form 
 * The result is posted in the URL http://localhost:3000/fibonacci
 * @param {number} number
 * @yields {Number} The fibonacci sequence numbers
 */
app.post('/fibonacci',urlencodedParser, function(req, res) {		
	//console.log( req.body.number);
	 if (!req.body) {
	 	return res.sendStatus(400)
	 }

	// Call computeFib() to generate fibonacci numbers and render the result to the webpage	
	var fibonacciNumbers = computeFib(req.body.number);		
	res.render('index',{ result: fibonacciNumbers });	
	res.end();	
}); 
